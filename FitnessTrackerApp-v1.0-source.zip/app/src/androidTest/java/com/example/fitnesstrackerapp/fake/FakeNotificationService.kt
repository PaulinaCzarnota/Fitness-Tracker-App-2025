package com.example.fitnesstrackerapp.fake

/**
 * Minimal fake service for testing.
 */
class FakeNotificationService
