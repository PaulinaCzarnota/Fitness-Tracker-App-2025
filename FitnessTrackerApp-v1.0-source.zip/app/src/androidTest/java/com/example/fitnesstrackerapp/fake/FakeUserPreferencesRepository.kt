package com.example.fitnesstrackerapp.fake

/**
 * Minimal fake repository for testing.
 */
class FakeUserPreferencesRepository
