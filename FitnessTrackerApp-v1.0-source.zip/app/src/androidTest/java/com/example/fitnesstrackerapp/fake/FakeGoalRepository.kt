package com.example.fitnesstrackerapp.fake

/**
 * Minimal fake repository for testing.
 */
class FakeGoalRepository {
    suspend fun createStepGoal() {}
    suspend fun createWorkoutGoal() {}
}
